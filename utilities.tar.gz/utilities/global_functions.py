def absolute_value(x):
    return abs(x)
