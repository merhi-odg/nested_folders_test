from . import absolute_value

def square_root(x):
    return x**.5

global_var="global_var"